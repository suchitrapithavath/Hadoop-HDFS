*******************************************************CS226-Assignment-1******************************************************************8

HDFSUpload folder contains the pom.xml,src and target folder where target got created by running maven package.

Following command is used to run the file:

hadoop jar HDFSUpload-1.0-SNAPSHOT.jar edu.ucr.cs.cs226.spith001.HDFSUpload AREAWATER.csv AREAWATERhdfsfile.csv

